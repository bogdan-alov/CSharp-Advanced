﻿namespace _01.Stream_Progress
{
    public class Program
    {
        public static void Main()
        {

        }
    }
}
