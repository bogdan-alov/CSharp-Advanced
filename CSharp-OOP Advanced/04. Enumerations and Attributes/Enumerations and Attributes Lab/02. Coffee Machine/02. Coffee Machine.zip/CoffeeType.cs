﻿using System;

public enum CoffeeType
{
	Espresso,
	Latte,
	Irish
}

