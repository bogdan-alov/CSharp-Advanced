﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class HeroInventory : IInventory
{
    [Item]
    private Dictionary<string, IItem> commonItems;

	[Item]
    private Dictionary<string, IRecipe> recipeItems;

    public HeroInventory()
    {
        this.commonItems = new Dictionary<string, IItem>();
        this.recipeItems = new Dictionary<string, IRecipe>();
    }

    public long TotalStrengthBonus
    {
        get { return this.commonItems.Values.Sum(i => i.StrengthBonus); }
    }

    public long TotalAgilityBonus
    {
        get { return this.commonItems.Values.Sum(i => i.AgilityBonus); }
    }

    public long TotalIntelligenceBonus
    {
        get { return this.commonItems.Values.Sum(i => i.IntelligenceBonus); }
    }

	public int CommonItemsCount
	{
		get => this.commonItems.Count;
	}
	public int RecipeItemsCount
	{
		get => this.recipeItems.Count;
	}

	public long TotalHitPointsBonus
    {
        get { return this.commonItems.Values.Sum(i => i.HitPointsBonus); }
    }

    public long TotalDamageBonus
    {
        get { return this.commonItems.Values.Sum(i => i.DamageBonus); }
    }

    public void AddCommonItem(IItem item)
    {
        this.commonItems.Add(item.Name, item);
        this.CheckRecipes();
    }

    public void AddRecipeItem(Recipe recipe)
    {
		this.recipeItems.Add(recipe.Name, recipe);
    }

	public void AddRecipeItems(Recipe recipe, List<string> args)
	{
		for (int i = 0; i < args.Count; i++)
		{
			recipe.RequiredItems.Add((Common)commonItems[args[i]]);
		}
		this.CheckRecipes();
	}
	public void AddCommonItem(Common item)
	{
		this.commonItems.Add(item.Name, item);
		this.CheckRecipes();
	}

	private void CheckRecipes()
    {
        foreach (IRecipe recipe in this.recipeItems.Values)
        {
            List<Common> requiredItems = new List<Common>(recipe.RequiredItems);
	        var itemsToRemove = new Dictionary<string, IItem>(commonItems);
            foreach (IItem commonItem in itemsToRemove.Values)
            {
                if (requiredItems.Any(c=> c.Name == commonItem.Name))
                {
                    recipe.RequiredItems.Remove((Common)commonItem);
	                this.commonItems.Remove(commonItem.Name);
                }
            }

            if (recipe.RequiredItems.Count == 0)
            {
                this.CombineRecipe((Recipe)recipe);
            }
        }
    }

    private void CombineRecipe(Recipe recipe)
    {
		
        for (int i = 0; i < recipe.RequiredItems.Count; i++)
        {
            string item = recipe.RequiredItems[i].ToString();
            this.commonItems.Remove(item);
        }
        IItem newItem = new Common(recipe.Name,
            recipe.StrengthBonus,
            recipe.AgilityBonus,
            recipe.IntelligenceBonus,
            recipe.HitPointsBonus,
            recipe.DamageBonus);

        this.commonItems.Add(newItem.Name, newItem);
    }


	public void GetAllItems(StringBuilder sb)
	{
		foreach (var commonItem in this.commonItems)
		{
			sb.AppendLine(commonItem.Value.ToString());
		}
	}

	public List<string> GetAllItems()
	{
		return this.commonItems.Values.Select(c=> c.Name).ToList();
	}
}