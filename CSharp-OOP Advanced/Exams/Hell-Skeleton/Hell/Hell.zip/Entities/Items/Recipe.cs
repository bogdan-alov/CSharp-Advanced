﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



public class Recipe : Item, IRecipe
{
	public Recipe(string name, int strengthBonus, int agilityBonus, int intelligenceBonus, int hitPointsBonus, int damageBonus) : base(name, strengthBonus, agilityBonus, intelligenceBonus, hitPointsBonus, damageBonus)
	{
		this.RequiredItems = new List<Common>();
	}

	public IList<Common> RequiredItems { get; }

}

