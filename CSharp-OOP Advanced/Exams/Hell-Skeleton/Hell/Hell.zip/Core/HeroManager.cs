﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;


public class HeroManager : IManager
{
    private Dictionary<string, IHero> heroes;

	public HeroManager()
	{
		this.heroes = new Dictionary<string, IHero>();
	}
    public string AddHero(List<string> arguments)
    {
        string result = null;

        string heroName = arguments[0];
        string heroType = arguments[1];

        try
        {
            Type clazz = Type.GetType(heroType);
            var constructors = clazz.GetConstructors();
            IHero hero = (IHero) constructors[0].Invoke(new object[] {heroName});

	        heroes.Add(hero.Name, hero);
			result = string.Format($"Created {hero.GetType().Name} - {heroName}");
        }
        catch (Exception e)
        {
            return e.Message;
        }

        return result;
    }

    public string AddItemToHero(List<string> arguments)
    {
        string result = null;

        string itemName = arguments[0];
        string heroName = arguments[1];
        int strengthBonus = int.Parse(arguments[2]);
        int agilityBonus = int.Parse(arguments[3]);
        int intelligenceBonus = int.Parse(arguments[4]);
        int hitPointsBonus = int.Parse(arguments[5]);
        int damageBonus = int.Parse(arguments[6]);

        Common newItem = new Common(itemName, strengthBonus, agilityBonus, intelligenceBonus, hitPointsBonus,
            damageBonus);

	    heroes.FirstOrDefault(c => c.Value.Name == heroName).Value.AddCommonItem(newItem);

        result = string.Format(Constants.ItemCreateMessage, newItem.Name, heroName);
        return result;
    }

	public string AddRecipeToHero(List<string> arguments)
	{
		string result = null;

		string itemName = arguments[0];
		string heroName = arguments[1];
		int strengthBonus = int.Parse(arguments[2]);
		int agilityBonus = int.Parse(arguments[3]);
		int intelligenceBonus = int.Parse(arguments[4]);
		int hitPointsBonus = int.Parse(arguments[5]);
		int damageBonus = int.Parse(arguments[6]);

		Recipe recipe = new Recipe(itemName, strengthBonus, agilityBonus, intelligenceBonus, hitPointsBonus, damageBonus);
		heroes.FirstOrDefault(c=> c.Key == heroName).Value.AddRecipe(recipe, arguments.Skip(7).ToList());
		
		result = string.Format(Constants.RecipeCreatedMessage, recipe.Name, heroName);
		return result;
	}

    public string Inspect(List<string> arguments)
    {
        string heroName = arguments[0];

        return this.heroes[heroName].ToString();
    }

	public string Quit(List<string> arguments)
	{
		var sb = new StringBuilder();
		var counter = 1;
		foreach (var hero in heroes.Values)
		{
			sb.AppendLine($"{counter}. {hero.GetType().Name}: {hero.Name}");
			sb.AppendLine($"###HitPoints: {hero.HitPoints}");
			sb.AppendLine($"###Damage: {hero.Damage}");
			sb.AppendLine($"###Strength: {hero.Strength}");
			sb.AppendLine($"###Agility: {hero.Agility}");
			sb.AppendLine($"###Intelligence: {hero.Intelligence}");
			if (hero.Items > 0)
			{
				//sb.AppendLine($"###Items: {string.Join(" ", hero.GetAllItems()});
				var list = hero.GetAllItems();
				sb.AppendLine($"###Items: {string.Join(" ", list)}");
			}
			else
			{
				sb.AppendLine($"###Items: None");
			}
			counter++;
		}
		return sb.ToString().Trim();
	}
}