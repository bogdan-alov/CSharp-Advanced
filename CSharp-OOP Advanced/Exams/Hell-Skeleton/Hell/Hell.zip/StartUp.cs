﻿
public class StartUp
{
    public static void Main()
    {
        ConsoleReader reader = new ConsoleReader();
        ConsoleWriter writer = new ConsoleWriter();
        HeroManager manager = new HeroManager();

        Engine engine = new Engine(reader, writer, manager);
        engine.Run();
    }
}