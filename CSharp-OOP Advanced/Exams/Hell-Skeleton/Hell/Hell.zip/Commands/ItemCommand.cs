﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class ItemCommand : AbstractCommand
{
	public ItemCommand(IList<string> argsList, IManager manager) : base(argsList, manager)
	{
	}

	public override string Execute()
	{
		return this.Manager.AddItemToHero(ArgsList);
	}
}

