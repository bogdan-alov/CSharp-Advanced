﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public interface IHero
{
	string Name { get; }
	long Strength { get; }
	long Agility { get; }
	long Intelligence { get; }
	long HitPoints { get; }
	long Damage { get; }
	long PrimaryStats { get; }
	long SecondaryStats { get; }
	void AddRecipe(Recipe recipe, List<string> args);
	void AddCommonItem(Common item);
	int Items { get; }
	List<string> GetAllItems();
}
