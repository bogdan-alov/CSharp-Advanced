﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public interface IManager
{
	string AddHero(List<string> arguments);
	string AddItemToHero(List<string> arguments);
	string Inspect(List<String> arguments);
	string Quit(List<String> arguments);
	string AddRecipeToHero(List<string> arguments);
}

