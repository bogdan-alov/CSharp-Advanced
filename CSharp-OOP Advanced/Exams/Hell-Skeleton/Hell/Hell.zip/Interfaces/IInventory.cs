﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public interface IInventory
{
	void AddRecipeItem(Recipe recipe);
	void AddCommonItem(Common item);
	long TotalDamageBonus { get; }
	long TotalHitPointsBonus { get; }
	long TotalStrengthBonus { get; }
	long TotalAgilityBonus { get; }
	long TotalIntelligenceBonus { get; }
	int CommonItemsCount { get; }
	int RecipeItemsCount { get; }
	void GetAllItems(StringBuilder sb);
	void AddRecipeItems(Recipe recipe, List<string> args);
	List<string> GetAllItems();
}

