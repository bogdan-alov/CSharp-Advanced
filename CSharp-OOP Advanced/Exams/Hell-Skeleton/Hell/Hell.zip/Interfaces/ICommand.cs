﻿using System.Collections.Generic;

public interface ICommand
{
	List<string> ArgsList { get; }
	IManager Manager { get; }
	string Execute();
}

