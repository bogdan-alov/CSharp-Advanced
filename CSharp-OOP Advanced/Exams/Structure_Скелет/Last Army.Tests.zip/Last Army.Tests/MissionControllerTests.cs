﻿using System.Collections.Generic;
using NUnit.Framework;

[TestFixture]
public class MissionControllerTests
{
	private MissionController missionController;
	private IArmy army;
	private IWareHouse wareHouse;

	[SetUp]
	public void TestInit()
	{
		this.missionController = new MissionController(army, wareHouse);
	}

	[Test]
	public void CheckExecuteMission()
	{
		// Arrange
		var mission = new Easy(1500);
		var soldier = new Corporal("Peshko", 1,1,1);
		var missonTeam = new List<ISoldier>();
		missonTeam.Add(soldier);
		
		// Act

		var s = this.missionController.PerformMission(mission);


		// Assert
		Assert.IsTrue($"Mission on hold - {mission.Name}" == s);

	}
}

