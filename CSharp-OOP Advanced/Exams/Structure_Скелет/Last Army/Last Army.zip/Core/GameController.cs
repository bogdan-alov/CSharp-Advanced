﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Last_Army.Core;


public class GameController
{
	//private Dictionary<string, List<Soldier>> army;
	//private Dictionary<string, List<Ammunition>> wearHouse;

	private Army army;
	private WareHouse wearHouse;

	private MissionController missionControllerField;
	private SoldierController soldierControllerField;


	private MissionFactory missionFactory;
	private SoldierFactory soldiersFactory;
	private AmmunitionFactory ammunitionFactory;

	public GameController()
	{
		this.army = new Army();
		this.wearHouse = new WareHouse();
		this.MissionControllerField = new MissionController(army, wearHouse);
		this.missionFactory = new MissionFactory();
		this.soldiersFactory = new SoldierFactory();
		this.ammunitionFactory = new AmmunitionFactory();
	}


	public MissionController MissionControllerField
	{
		get { return missionControllerField; }
		set { missionControllerField = value; }
	}

	public void GiveInputToGameController(string input)
	{
		var data = input.Split();

		if (data[0].Equals("Soldier"))
		{
			string type = string.Empty;
			string name = string.Empty;
			int age = 0;
			int experience = 0;
			double endurance = 0d;

			if (data.Length == 3)
			{
				type = data[1];
				name = data[2];
			}
			else
			{
				type = data[1];
				name = data[2];
				age = int.Parse(data[3]);
				experience = int.Parse(data[4]);
				endurance = double.Parse(data[5]);
			}


			switch (type)
			{
				case "Ranker":
					var ranker = soldiersFactory.CreateSoldier(type,name, age, experience, endurance);
					AddSoldierToArmy((Soldier)ranker);
					break;
				case "Corporal":
					var corporal = soldiersFactory.CreateSoldier(type,name, age, experience, endurance);
					AddSoldierToArmy((Soldier)corporal);
					break;
				case "Special-Force":
					var specialForce = soldiersFactory.CreateSoldier(type,name, age, experience,endurance);
					AddSoldierToArmy((Soldier)specialForce);
					break;
				case "Regenerate":
					soldierControllerField.TeamRegenerate(army, type);
					break;
			}

		}
		else if (data[0].Equals("WareHouse"))
		{
			string name = data[1];
			int count = int.Parse(data[2]);

			for (int i = 0; i < count; i++)
			{
				if (name == "Gun")
				{
					AddAmmunitions(new Gun("Gun"));
				}
				else if (name == "AutomaticMachine")
				{

					AddAmmunitions(new AutomaticMachine("AutomaticMachine"));
				}
				else if (name == "Helmet")
				{
					AddAmmunitions(new Helmet("Helmet"));

				}
				else if (name == "Knife")
				{
					AddAmmunitions(new Knife("Knife"));
				}
				else if (name == "MachineGun")
				{
					AddAmmunitions(new MachineGun("MachineGun"));
				}
				else if (name == "NightVision")
				{
					AddAmmunitions(new NightVision("NightVision"));
				}
				else if (name == "RPG")
				{
					AddAmmunitions(new RPG("RPG"));
				}
			}

		}
		else if (data[0].Equals("Mission"))
		{
			var type = data[1];
			var score = double.Parse(data[2]);

			var mission = missionFactory.CreateMission(type, score);
			var oldArmy = army;
			this.army.Where(c => c.ReadyForMission(mission)).Cast<Army>();
			
			this.MissionControllerField.PerformMission(mission);
			this.army = oldArmy;
		}
	}


	public string RequestResult(StringBuilder result)
	{
		//return Output.GiveOutput(result, army, wearHouse, this.MissionControllerField.MissionQueue.Count);
		return "";
	}

	private void AddAmmunitions(Ammunition ammunition)
	{
		this.wearHouse.AddToWearhouse(ammunition);
	}

	private void AddSoldierToArmy(Soldier soldier)
	{
		if (soldier.CanBeAddedToArmy(wearHouse))
		{
			//soldier.
		}
		this.army.AddSoldier(soldier);
	}
}
