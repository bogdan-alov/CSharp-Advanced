﻿using System;
using System.Text;
using Last_Army.IO;

public class Engine
{
	private ConsoleReader consoleReader = new ConsoleReader();
	private ConsoleWriter consoleWriter = new ConsoleWriter();

	public void Run()
	{
		
		var input = consoleReader.ReadLine();
		var gameController = new GameController();
		var result = new StringBuilder();

		while (!input.Equals("Enough! Pull back!"))
		{
			try
			{
				gameController.GiveInputToGameController(input);
			}
			catch (ArgumentException arg)
			{
				result.AppendLine(arg.Message);
			}
			input = consoleReader.ReadLine();
		}

		gameController.RequestResult(result);
		consoleWriter.WriteLine(result.ToString());
	}
}

