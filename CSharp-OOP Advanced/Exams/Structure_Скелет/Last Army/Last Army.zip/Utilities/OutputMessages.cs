﻿
public class OutputMessages
{
	// SoldierToString
	public const string MissionDeclined = "Created {0} - {1}";

	public const string MissionOnHold = "Mission on hold - {0}”";

	public const string MissionSuccessful = "Added recipe - {0} to Hero - {1}";

	public const string SoldierToString = "{0} - {1}";

}

