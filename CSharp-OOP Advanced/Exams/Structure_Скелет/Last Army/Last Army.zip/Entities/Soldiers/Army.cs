﻿
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

public class Army : IArmy, IEnumerable<ISoldier>
{
	private IList<ISoldier> soldiers;
	public Army()
	{
		this.soldiers = new List<ISoldier>();
	}
	public IReadOnlyList<ISoldier> Soldiers
	{
		get => (IReadOnlyList<ISoldier>)soldiers;
	}
	public void AddSoldier(ISoldier soldier)
	{
		this.soldiers.Add(soldier);
	}

	public void RegenerateTeam(string soldierType)
	{
		var soldiersToRegenerate = this.soldiers.Where(c => c.GetType().Name.Equals(soldierType)).ToList();


		foreach (var soldier in soldiersToRegenerate)
		{
			soldier.Regenerate();
		}
	}

	public IEnumerator<ISoldier> GetEnumerator()
	{
		for (int i = 0; i < soldiers.Count; i++)
		{
			yield return soldiers[i];
		}
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}
}

