﻿
using System.Collections.Generic;
using System.Runtime.CompilerServices;

public class Corporal : Soldier
{
	
	private readonly List<string> weaponsAllowed = new List<string>
	{
		"Gun",
		"AutomaticMachine",
		"MachineGun",
		"Helmet",
		"Knife"
	};
	public Corporal(string name, int age, double experience, double endurance) : base(name, age, experience, endurance)
	{
		this.WeaponsAllowed = weaponsAllowed;
		this.OverallSkill = (age + experience) * 2.5;
	}

	protected override IReadOnlyList<string> WeaponsAllowed { get; }
}

