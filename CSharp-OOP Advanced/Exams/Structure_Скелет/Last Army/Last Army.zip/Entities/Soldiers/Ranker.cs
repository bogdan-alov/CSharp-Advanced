﻿
using System.Collections.Generic;

public class Ranker : Soldier
{
	private readonly List<string> weaponsAllowed = new List<string>
	{
		"Gun",
		"AutomaticMachine",
		"Helmet"
	};

	public Ranker(string name, int age, double experience, double endurance) : base(name, age, experience, endurance)
	{
		this.WeaponsAllowed = weaponsAllowed;
		this.OverallSkill = (age + experience) * 1.5;
	}
	protected override IReadOnlyList<string> WeaponsAllowed { get; }


}
