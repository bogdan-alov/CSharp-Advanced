﻿
public class Medium : Mission
{
	public Medium(double scoreToComplete) : base(scoreToComplete)
	{
		this.EnduranceRequired = 50;
	}
}

