﻿
public class Hard : Mission
{
	public Hard(double scoreToComplete) : base(scoreToComplete)
	{
		this.EnduranceRequired = 80;
	}
}

