﻿
public class Easy : Mission
{

	public Easy(double scoreToComplete) : base(scoreToComplete)
	{
		this.EnduranceRequired = 20;
	}
}

