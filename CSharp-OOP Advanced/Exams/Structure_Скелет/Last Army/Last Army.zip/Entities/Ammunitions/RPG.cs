﻿
public class RPG : Ammunition
{
	private const double weight = 17.1;

	public RPG(string name)
		: base(name, weight)
	{
	}
}
