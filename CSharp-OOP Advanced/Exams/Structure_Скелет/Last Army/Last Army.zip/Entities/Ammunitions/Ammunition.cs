﻿using System;

public abstract class Ammunition : IAmmunition
{
	protected Ammunition(string name, double weight)
	{
		Name = name;
		Weight = weight;
		this.WearLevel = 100 * weight;
	}
	public string Name { get;  }
	public double Weight { get; }
	public double WearLevel { get; }
	public void DecreaseWearLevel(double wearAmount)
	{
		throw new NotImplementedException();
	}
}

