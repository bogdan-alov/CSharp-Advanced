﻿
using System;
using System.Collections;
using System.Collections.Generic;

public class WareHouse : IWareHouse, IEnumerable<Ammunition>
{
	public WareHouse()
	{
		this.ammunitions = new List<Ammunition>();

	}

	private IList<Ammunition> ammunitions;

	public void AddToWearhouse(Ammunition ammunition)
	{

		this.ammunitions.Add(ammunition);

	}

	public void EquipArmy(Army army)
	{
		foreach (var soldier in army)
		{
			//foreach (var VARIABLE in soldier.)
			//{
				
			//}
		}
	}

	public IEnumerator<Ammunition> GetEnumerator()
	{
		for (int i = 0; i < ammunitions.Count; i++)
		{
			yield return ammunitions[i];
		}

	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}
}

