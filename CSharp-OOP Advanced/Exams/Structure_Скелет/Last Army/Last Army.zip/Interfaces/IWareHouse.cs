﻿
using System.Collections.Generic;

public interface IWareHouse
{
	void AddToWearhouse(Ammunition ammunition);
	void EquipArmy(Army army);
}

