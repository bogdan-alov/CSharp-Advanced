﻿
public class MissionFactory
{
	public IMission CreateMission(string type, double score)
	{
		return new Easy(score);
	}

}

