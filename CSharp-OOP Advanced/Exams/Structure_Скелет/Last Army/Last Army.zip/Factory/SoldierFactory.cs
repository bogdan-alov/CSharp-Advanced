﻿
public class SoldierFactory
{
	public SoldierFactory()
	{
	}

	public SoldierFactory(string name, int age, double experience, double endurance)
	{
		this.name = name;
		this.age = age;
		this.experience = experience;
		this.endurance = endurance;
	}
	//string name, int age, double experience, double endurance
	public ISoldier CreateSoldier(string type,string name, int age, int experience, double endurance)
	{
		if (type == "Ranker")
		{
			return new Ranker(name, age, experience, endurance);
		}
		if (type == "Corporal")
		{
			return new Corporal(name, age, experience, endurance);
		}

		return new SpecialForce(name, age, experience, endurance);
	}

	public ISoldier CreateSoldier(SoldierFactory sf)
	{
		
		return new SpecialForce(name, age, experience, endurance);
	}

	public Soldier CreateSoldier()
	{
		return new SpecialForce(name, age, experience, endurance);
	}

	//public Soldier GenerateRanker(string name, int age, int experience, double endurance)
	//{
	//	return new Ranker(name, age, experience, endurance);
	//}

	//public Soldier GenerateCorporal(string name, int age, int experience, double endurance)
	//{
	//	return new Corporal(name, age, experience, endurance);
	//}

	//public Soldier GenerateSpecialForce(string name, int age, int experience, double endurance)
	//{
	//	return new SpecialForce(name, age, experience, endurance);
	//}

	private string name;
	private int age;
	private double experience;
	private double endurance;
}
