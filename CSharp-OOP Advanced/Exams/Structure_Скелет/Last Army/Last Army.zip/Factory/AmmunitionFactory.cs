﻿
    public class AmmunitionFactory
    {
        public AmmunitionFactory()
        {
        }

        public IAmmunition CreateAmmunition(string name)
        {
            switch (name)
            {
                case "Helmet":
                    return new Helmet(name);
                case "Knife":
                    return new Knife(name);
                case "NightVision":
                    return new NightVision(name);
                case "AutomaticMachine":
                    return new AutomaticMachine(name);
                case "Gun":
                    return new Gun(name);
                case "MachineGun":
                    return new MachineGun(name);
            }
            //if none of the above did not match it will be RPG
            return new RPG(name);
        }

        public IAmmunition CreateAmmunitions(string name)
        {
            switch (name)
            {
                case "Helmet":
                    return new Helmet(name);
                case "Knife":
                    return new Knife(name);
                case "NightVision":
                    return new NightVision(name);
                case "AutomaticMachine":
                    return new AutomaticMachine(name);
                case "Gun":
                    return new Gun(name);
                case "MachineGun":
                    return new MachineGun(name);
            }
            //if none of the above did not match it will be RPG
            return new RPG(name);
        }

	
    }
