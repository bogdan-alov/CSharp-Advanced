﻿using System;
using System.Text;
using Last_Army.Core;
using Last_Army.IO;


public class LastArmyMain
{
	public static void Main()
	{
		var engine = new Engine();
		engine.Run();
	}
}
