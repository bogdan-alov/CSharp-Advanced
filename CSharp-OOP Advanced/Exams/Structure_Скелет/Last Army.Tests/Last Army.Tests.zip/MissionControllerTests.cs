﻿using System.Collections.Generic;
using NUnit.Framework;

[TestFixture]
public class MissionControllerTests
{
	private MissionController missionController;
	private IArmy army;
	private IWareHouse wareHouse;

	[SetUp]
	public void TestInit()
	{
		this.missionController = new MissionController(army, wareHouse);
		//wareHouse.AddToWearhouse(new Gun("Peshko"));
		//wareHouse.AddToWearhouse(new AutomaticMachine("Peshko"));
		//wareHouse.AddToWearhouse(new Knife("Peshko"));
		//wareHouse.AddToWearhouse(new RPG("Peshko"));
		//wareHouse.AddToWearhouse(new MachineGun("Peshko"));
		//wareHouse.AddToWearhouse(new NightVision("Peshko"));

	}

	[Test]
	public void CheckExecuteMission()
	{
		// Arrange
		var mission = new Easy(1500);
		var soldier = new Corporal("Peshko", 1,1,1);
		var missonTeam = new List<ISoldier>();
		missonTeam.Add(soldier);
		
		// Act

		var s = this.missionController.PerformMission(mission);


		// Assert
		Assert.IsTrue($"Mission on hold - {mission.Name}" == s);

	}


	[Test]
	public void CheckCounterOfFailedMissions()
	{
		// Arrange
		var mission = new Easy(1500);

		// Act

		missionController.PerformMission(mission);


		// Assert

		Assert.IsTrue(missionController.FailedMissionCounter == 0);
	}

	[Test]
	public void CheckCounterOfActiveMissions()
	{
		// Arrange
		var mission = new Easy(1);
		var soldier = new Corporal("Peshko", 25, 700, 120);
		this.army.AddSoldier(soldier);
		// Act

		missionController.PerformMission(mission);


		// Assert

		Assert.IsTrue(missionController.SuccessMissionCounter == 1);
	}


	[Test]
	public void CheckIfMissionIsCompleted()
	{
		// Arrange
		var mission = new Easy(1);
		var soldier = new Corporal("Peshko", 25, 700, 100);
		army.AddSoldier(soldier);

		// Act

		var s = this.missionController.PerformMission(mission);


		// Assert
		Assert.IsTrue($"Mission completed - {mission.Name}" == s);

	}
}

