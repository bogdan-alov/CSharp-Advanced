﻿using System;


class Startup
	{
		static void Main(string[] args)
		{
			
		}
	}

