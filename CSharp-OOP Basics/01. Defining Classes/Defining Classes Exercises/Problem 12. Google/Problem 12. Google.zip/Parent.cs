﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_12.Google
{
	class Parent
	{

		public string Name { get; set; }

		public string BirthDate { get; set; }
	}
}
