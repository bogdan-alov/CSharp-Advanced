﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_12.Google
{
	class Car
	{

		public string Name { get; set; }

		public int Power { get; set; }
	}
}
