﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_08.Raw_Data
{
	class Tire
	{
		public double Pressure { get; set; }
		public int Age { get; set; }
	}
}
