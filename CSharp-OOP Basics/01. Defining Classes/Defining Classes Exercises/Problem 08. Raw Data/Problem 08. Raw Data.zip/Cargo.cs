﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_08.Raw_Data
{
	class Cargo
	{
		public int Weight { get; set; }
		public string Type { get; set; }
	}
}
